export const config = {
    host: 'localhost',
    username: 'root',
    password: '', 
    database: 'nodepoint'  
}

