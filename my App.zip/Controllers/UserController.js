import reply from "../Common/reply.js";
import axios from "axios";
import User from "../Models/User.js";
import Token from "../Models/Token.js";
import Otp from "../Models/Otps.js";
import Template from "../Models/Template.js";
import nodemailer from 'nodemailer';
import bcrypt from "bcrypt";
import Validator from "validatorjs";
import JWT from 'jsonwebtoken';
import fs from 'fs';
import crypto from "crypto";
import verifyCaptcha from '../Traits/verifyRecaptcha.js';
import { SendOtp, generateActivityLog } from '../Traits/SendOtp.js';
import SaveOtp from '../Traits/OtpHandler.js';
import { UserCreateRule, UserLoginRule } from "../Rules/userRules.js";
import ActivityLog from "../Models/ActivityLog.js";
import _ from "lodash";

function firstError(validator) {
    let first_key = Object.keys(validator.errors.errors)[0];
    return validator.errors.first(first_key);
}

const imageupload = (req, res) => {
    if (!req.filedata || req?.filedata?.status_code == 0) {
        return res.send(reply.failed(req?.filedata?.message));
    }
    return res.send(reply.success("File uploaded successfully!!", req?.filedata?.message));
}


const comparePassword = (pass, hash) => {
    return bcrypt.compare(pass, hash)
        .then(result => {
            return result
        })
        .catch(err => {
            return false;
        });
}

const register = async (req, res) => {
    var request = req.body;

    let message = { "regex.password": "The password must contain at least one uppercase, one lowercase letter and one special character" };
    let validator = new Validator(request, UserCreateRule, message);
    if (validator.fails()) { return res.json(reply.failed(firstError(validator))); }

    const Is_email_available = await User.findOne({
        raw: true,
        where: { email: request.email }
    });
    if (Is_email_available) { return res.json(reply.failed("Email already exists.!!.")); }

    try {
        request.password = await bcrypt.hash(request.password, 10);
        await User.create(request);
        return res.json(reply.success("Registered Successfully!!"));
    } catch (err) {
        console.log({ error: err });
        return res.json(reply.failed("Server is busy right now, Please try it later!!"));
    }
}

const login = async (req, res) => {
    var request = req.body;

    let validator = new Validator(request, UserLoginRule);
    if (validator.fails()) {
        return res.json(reply.failed(firstError(validator)));
    }

    try {
        const user = await User.findOne({ where: { email: request.email }, raw: true });
        if (!user) { return res.json(reply.failed("The selected email is invalid.")) }

        let date_expiry = new Date((new Date().setDate(new Date().getDate() + 7))).toISOString();

        let is_password = await comparePassword(request.password, user.password);
        if (!is_password) { return res.send(reply.failed("Invalid Credentials!!")); }

        const PRIVATE_KEY = fs.readFileSync('./keys/Private.pem', 'utf-8');
        const tokenid = crypto.randomBytes(80).toString('hex');
        let token = "";
        JWT.sign({ tokenid }, PRIVATE_KEY, { algorithm: 'RS256', expiresIn: '7d' }, (err, t) => { token = t });

        let form_data = {
            t_id: tokenid,
            user_id: user.id,
            email: user.email,
            expired_at: date_expiry
        }

        // const captcha_result = await verifyCaptcha(request.captcha_response);
        // if(!captcha_result.success) { return res.json(reply.failed("Invalid Re-Captcha!!")); }
        // console.log(user.user_verify == 1 && user.status == 1);

        request['ip'] = (req.ip).substring(7, 20);

        if (user.user_verify == 1 && user.status == 1) {
            if (user.role == 'user') {
                return res.json(reply.failed('Access Denied'))
            }

            if (user._2fa == 2) {
                let except = _.omit(request, ['password']);
                let otpArray = await SaveOtp(request.email, 'login', 'email', 'verifyLoginEmail');

                let mail = await SendOtp(otpArray.otp, 'email', 'login');
                // console.log("ddd", mail);

                const transporter = nodemailer.createTransport({
                    service:  process.env.MAIL_MAILER,                                                           
                    host: process.env.MAIL_HOST,
                    port: process.env.MAIL_PORT,
                    secure: false,
                    auth: {
                        user: process.env.MAIL_USERNAME,
                        pass: process.env.MAIL_PASSWORD
                    }
                  });
                  const mailOptions = {
                    from: process.env.MAIL_FROM_ADDRESS,
                    to: user['email'],
                    subject: 'Teste Templete ✔',
                    html: `<b>Hello world? ${otpArray.otp}</b>` 
                };
                
                transporter.sendMail(mailOptions, (error, info) => {
                    if (error) {
                        return console.log(error,":sss");
                    }
                    console.log('Message %s sent: %s', info.messageId, info.response);
                });
                
                await generateActivityLog(user.id, 'loginError', request['ip']);
                return res.send(reply.success("Otp Sent on your Email.", otpArray));
            }            
        }

        await generateActivityLog(user.id, 'login', request['ip']);
        await Token.create(form_data);
        let except = _.omit(user, ['password']);
        return res.send(reply.success("LoggedIn Successfully!!", except, { token }));
    }
    catch (err) {
        console.log("error",err);
        return res.send(reply.failed("Server is busy right now, Please try it later!!"));
    }
}
// const LOGIN_DATA_FIELDS = ['id', 'name', 'email', 'mobile', 'profile_image', 'status', 'referral_code', 'fee_by_lbm'];



const fetch = async (req, res) => {
    try {
        const user = await User.findOne({
            attributes: { exclude: ['password'] },
            where: { id: req.user.id }
        });
        return res.json(reply.success("Users Fetched Successfully!!", user ?? []));
    } catch (err) {
        return res.json(reply.failed("Unable to fetch user detail"));
    }
}

const hard_logout = async (req, res) => {
    let exist = await Token.destroy({ where: { user_id: req.user.id } });
    return (exist) ? res.send(reply.success("Logout Successfully!!")) : res.send(reply.failed("Server is busy right now!!"));
}

const soft_logout = async (req, res) => {
    let { id, t_id } = req.user;
    let exist = await Token.destroy({ where: { user_id: id, t_id } });
    return (exist) ? res.send(reply.success("Logout Successfully!!")) : res.send(reply.failed("Server is busy right now!!"));
}

export default {
    imageupload,
    register,
    login,
    fetch,
    hard_logout,
    soft_logout
}


