import jwt from "jsonwebtoken";
import reply from "../common/reply.js";
import fs from "fs";
import Token from "../models/Token.js";
import User from "../models/User.js";


export default (req, res, next) => {

    let Authorization = req.headers['authorization'];

    if (Authorization == undefined) {
        return res.send(reply.failed("Invalid Token!"));
    }

    let token = Authorization.split("Bearer ")[1];

    if (!token) {
        return res.send(reply.failed("Invalid Token!!"));
    }

    var public_key = fs.readFileSync("./keys/Public.pem", "utf-8");

    jwt.verify(token, public_key, { algorithms: ['RS256'] }, async (err, decoded) => {
        if (err) {
            return res.send(reply.failed(err.message));
        }

        let T = await Token.findOne({
            where: {
                t_id: decoded.t_id
            }
        });

        if (!T) {
            return res.send(reply.failed("Token Expired!!"));
        }

        let user = await User.findOne({
            where: {
                id: T.user_id,
                role: "admin"
            }
        });

        if (!user) {
            return res.send(reply.failed("Protected Routes, Only Access by Admin!!"));
        }

        req.user = user;
        next();
    });
}