import { Model, Sequelize } from '../Database/connectionsDB.js';
const ActivityLog = Model.define("activity_log", {
    user_id: Sequelize.STRING,
    type: Sequelize.STRING,
    ip: Sequelize.STRING,
    message: Sequelize.STRING
});

ActivityLog.sync();
export default ActivityLog;