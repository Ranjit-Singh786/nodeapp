import { Model, Sequelize } from '../Database/connectionsDB.js';
const Otp = Model.define("otp", {
    email: Sequelize.STRING,
    otp_type: Sequelize.STRING,
    send_type: Sequelize.STRING,
    otp: Sequelize.STRING,
    callback: Sequelize.STRING,
    cb_params: Sequelize.STRING
});

Otp.sync();
export default Otp;
