import { Model, Sequelize } from '../Database/connectionsDB.js';
const Template = Model.define("template", {
    admin_id: Sequelize.STRING,
    type: Sequelize.STRING,
    temp_type: Sequelize.STRING,
    status:{
     type: Sequelize.STRING,
     defaultValue: 0,
     comment: "1=Active , 0=Not Active"
    },        
    content: Sequelize.STRING
});

Template.sync();
export default Template;