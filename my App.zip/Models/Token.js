import { Model, Sequelize } from '../Database/connectionsDB.js';

const Token = Model.define('oauth_access_tokens',{
    t_id: Sequelize.STRING,
    user_id: Sequelize.BIGINT(20).UNSIGNED ,
    email: Sequelize.STRING,
    expired_at: Sequelize.DATE
});

// await Token.sync({ force: true });
await Token.sync();
export default Token;