import { Model, Sequelize } from '../Database/connectionsDB.js';

const User = Model.define("user", {
    fname: Sequelize.STRING,
    lname: Sequelize.STRING,
    email: Sequelize.STRING,
    password: Sequelize.STRING,
    role: Sequelize.STRING,
    email_verified_at: Sequelize.DATE,
    mobile: Sequelize.STRING,
    mobile_verified_at: Sequelize.DATE,
    user_verify: {
        type: Sequelize.TINYINT,
        defaultValue: 0,
        
    },
    otp_status: {
        type: Sequelize.TINYINT,
        defaultValue: 0,
    },
    _2fa: {
        type: Sequelize.TINYINT,
        defaultValue: 2,
    },
    status: {
        type: Sequelize.TINYINT,
        defaultValue: 1,
        comments:"1=Active , 0=Blocked"
    }
});

// await User.sync({ force: true });
User.sync();
export default User;