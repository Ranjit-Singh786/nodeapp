import express from "express";
import UserController from "../Controllers/UserController.js";
import UserAuthorization from "../Middleware/UserAuthenticate.js";
import fileUpload from "../Upload/FileUpload.js";


const UploadImageWithPath = (req, res, next) => {
    req.headers['mypath'] = "/";
    return fileUpload(req, res, next);
  }


  
const router = express.Router();




router.post("/register", UserController.register);
router.get("/get",UserAuthorization, UserController.fetch);
router.post("/login", UserController.login);
router.delete("/hard_logout", UserAuthorization, UserController.hard_logout);
router.delete("/logout", UserAuthorization, UserController.soft_logout);



router.post("/imageupload", UploadImageWithPath, UserController.imageupload);











// import multer from 'multer';
// import bodyparser from "body-parser";

// router.use(bodyparser.urlencoded({ extended: false }))
// router.use(bodyparser.json());

// const storage = multer.diskStorage({
//     destination: (req, file, cb) => {
//       cb(null, "uploads");
//     },
//       filename: (req, file, cb) => {
//           cb(null, Date.now()  + '_' + file.originalname)
           
//     }
// });
// const upload = multer({ storage:storage });

//upload.single('image')

export default router;