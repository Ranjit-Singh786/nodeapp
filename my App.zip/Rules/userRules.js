export const UserCreateRule = ({
    'fname': 'required|string|min:4|max:20',
    'email': 'required|email|min:4|max:100',
    'password': 'required|regex:/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/',
    'confirm_password': 'required|same:password',
})

export const UserLoginRule = {
    'email': 'required|email|min:4|max:100',
    'password': 'required|min:8',
    'captcha_response' : 'required'
}