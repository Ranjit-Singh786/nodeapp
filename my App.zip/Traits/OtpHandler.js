import Otp from './../Models/Otps.js';



const SaveOtp = async (email, type, sendType, callback = null, params = null) => {
    let otp = Math.floor(100000 + Math.random() * 900000);    
    let res = await Otp.create({
        "email": email,
        "otp_type": type,
        "send_type": sendType,
        "otp": otp,
        'callback': callback ?? '',
        'cb_params': params != null ? params : ''
    })
    return res ? res : 0;
}

export default SaveOtp;