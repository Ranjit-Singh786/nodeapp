import ActivityLog from "../Models/ActivityLog.js";
import Template from "../Models/Template.js";


const SendOtp = async (otp, type, temp_type) => {
    let html = await Template.create({
        'type': type,
        'temp_type': temp_type,
        'status': '1'
    }); 
    if(html == ''){
        if(temp_type == 'register'){
           return  html = "This is verification link From Lbm Solution. {link} ";
        }
        if(temp_type == 'login'){
             html = `This OTP ${otp} For ${type} From Lbm Solution.`;
            console.log(">>>>>>>>>",html); 
        }
    } 

   
    return html ? html : '';
}


const generateActivityLog = async (user_id, type, ip) => {
    let messageLog = {
        'login': 'Login Success',
        'loginError': 'Login Attempt',
        'logout': 'Logout Success',
        'hardlogout': 'ALL Device Logout Success',
        '_2faUpdate': 'Changed 2FA Success',
        '_2faError': '2FA Attempt'
    };
    let message = messageLog[type];
    await ActivityLog.create({ 'user_id': user_id, 'type': type, 'ip': ip, 'message': message });
}

export { 
    SendOtp, 
    generateActivityLog 
};
