import axios from "axios";

const verifyCaptcha = async (response_code) => {
  let url = 'https://www.google.com/recaptcha/api/siteverify';
  let body = 'response=' + response_code + '&secret=' + process.env.RECAPTCHA_SECRET_KEY;
  let headers = { 'Content-Type': 'application/x-www-form-urlencoded' }

  try {
    const response = await axios.post(url, body, headers);
    return response.data;
  } catch (error) {
    console.log({
      "status_code": error.response.status,
      "status_text":error.response.statusText
    });
  }
}

export default verifyCaptcha