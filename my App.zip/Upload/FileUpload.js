import multer from "multer";
import path from "path";
import reply from "../Common/reply.js";

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, `./assets/${req.headers.mypath}`);
    },
    filename: function (req, file, cb) {
        let extensionFile = path.extname(file.originalname);
        let saveFileName = `${Date.now()}${extensionFile}`;
        cb(null, saveFileName);
    }
});

const checkFileType = (file, cb) => {

    var ext = path.extname(file.originalname);

    if (ext !== '.png' && ext !== '.jpg' && ext !== '.jpeg' && ext !== '.pdf') {
        return cb(new Error('Only png, jpg , jpeg and pdf are allowed'));
    }

    return cb(null, true);
}

const upload = multer({
    storage: storage, fileFilter: (req, file, cb) => { checkFileType(file, cb) }
}).single("file");

const fileUpload = (req, res, next) => {
    upload(req, res, (err) => {

        if (err) {
            let result = reply.failed(err.message);
            req.filedata = result;
            next();
        }

        if (req.file == undefined) {
            req.filedata = reply.failed("Invalid Data!!");
            next();
        }

        req.filedata = reply.success(req.file?.filename);
        next();
    });
}

export default fileUpload;

