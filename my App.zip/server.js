import express from "express";
import bodyparser from "body-parser";
import reply from "./common/reply.js";
import { fileURLToPath } from 'url';
import path from 'path';



import dotenv from "dotenv";
dotenv.config();


// Express
const app = express();
app.use(express.json());

// PORT
const port = 3002;

// Body-parser
app.use(bodyparser.urlencoded({ extended: false }))
app.use(bodyparser.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);





// -------------------------------------------------------
//                      IMPORT ROUTES
//--------------------------------------------------------

import router from "./Routes/api.js";
app.use("/api", router);



app.get('/', (req, res) => {
    return res.send(reply.success("working"));
});

app.get("/image/:type/:path", (req, res) => {
    res.sendFile(__dirname + '/assets/' + req.params.type + '/' + req.params.path);
});


// -------------------------------------------------------
//                     Start Server
//--------------------------------------------------------

app.listen(port, async() => {
    console.log(`App running at: \n- Local:   http://localhost:${port}`, `\n- Network: ${process.env.base_url }`)
});
