
import mongoose from 'mongoose';

const conf = () => {


    mongoose.connect(process.env.MONGO_URI, {

        useNewUrlParser: true,
       
        useUnifiedTopology:true,
    }).then(()=>console.log('info','mongo is connected')).catch((err)=>console.log(err));

}

export default conf;