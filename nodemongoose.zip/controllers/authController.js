import User from '../models/user.js';
import Token from '../models/token.js';
import Otp from '../models/otps.js';
import crypto from "crypto";
// import bcrypt from "bcrypt";
import  Jwt  from 'jsonwebtoken';
import Validator from 'validatorjs';
import moment from 'moment';
import fs from "fs";
import nodemailer from "../config/mailer.js";
import { runInNewContext } from 'vm';
export default {
  Register: async (req, res) => {
    let validation = new Validator(req.body, {
      firstname:"required",
      lastname:"required",
      email: 'required|email',
      password: 'required',
  
    });
  
    if (validation.fails()) {
      let err_key = Object.keys(Object.entries(validation.errors)[0][1])[0];
      return res.json(res.json(validation.errors.first(err_key)));
    }
    const { firstname, lastname, email, password } = req.body;
    let user = await User.findOne({
      email
    });
    if (user)
      return res.json({
        status_code:0,
        message: "Email already Exist"
      });
    const post = new User({ firstname, lastname, email, password })

    try {
      let ress = await post.save();
      console.log(ress);
      res.json({status_code:1, message: "User created successfully", post })
    } catch (err) {
      console.log(err);
      res.json({status_code:0, message: 'invalid response' })
    }
  },

  loginUser: async (req, res) => {
    let validation = new Validator(req.body, {
      email: 'required|email',
      password: 'required',
  
    });
  
    if (validation.fails()) {
      let err_key = Object.keys(Object.entries(validation.errors)[0][1])[0];
      return res.json(res.json(validation.errors.first(err_key)));
    }
    // Email
    const { email, password } = req.body;
    console.log(req.body)
      const user = await User.findOne({
        email
      });
      if (!user)
        return res.json({
          status_code:0,
          message: "User Not Exist"
        });
 
      const isMatch = password==user.password?true:false;
      if (!isMatch)
        return res.json({
          status_code:0,
          message: "Incorrect Password !"
        });
      var token_ids= crypto.randomBytes(64).toString('hex');
     
      const PRIVATE_KEY = fs.readFileSync("./keys/Private.pem", "utf-8");
      // console.log(PRIVATE_KEY)
      token_ids= Jwt.sign({ token_ids }, PRIVATE_KEY, {algorithm: 'RS256', expiresIn: "1h" });
      console.log(token_ids,'chekc thae valdsh')
      if(token_ids){
      try{
        
             Token.create({user_id:user.id,token_id:token_ids})
            return res.json({status_code:1,message:"successfully login",user,token_ids})
        

      }catch(err){
             res.json({status_code:0,message:"error occured while creating",err});
      }
      }
  },
  ////////////////forgot password ////////////////////
  forgot_password:async (req,res)=>{
    let validation = new Validator(req.body, {
      email: 'required|email',
    });
    if (validation.fails()) {
      let err_key = Object.keys(Object.entries(validation.errors)[0][1])[0];
      return res.json(res.json(validation.errors.first(err_key)));
    }
     
    const user = await User.findOne({
       email:req.body.email
  });
  // console.log(!user)
  if(!user){
    return res.json("invalid email address");
  }
  let today = new Date();  
  var timeStamp = (moment(today).unix() )*1000 +(3*60000);
  let otp_gen = Math.floor(Math.random() * 899999 + 100000);
  let current_time =(moment(today).unix() )*1000;
  let otps={
    user_id:user.id,email:user.email,otp:otp_gen,expired_at:timeStamp
  }
  const otp = await Otp.findOne({
    email:user.email
});
if(otp==null){
  let otpc=  await Otp.create(otps);
  nodemailer.send(user.email, "" + otp_gen);
  return res.json({status_code:1,msg:'Otp send successfully',expired_at:otpc.expired_at});
 }else{
if(current_time<otp.expired_at){
  return res.json({msg:"your otp not expired yet"});
}else{
   
 Otp.deleteOne({ user_id: user.id},function(err,res){
    console.log(res)
 });
 
}
}
        
  },
  otp_verify:async (req,res)=>{
    let validation = new Validator(req.body, {
      email: 'required|email',
      otp:'required'
    });
    if (validation.fails()) {
      let err_key = Object.keys(Object.entries(validation.errors)[0][1])[0];
      return res.json(res.json(validation.errors.first(err_key)));
    }
    const otps = await Otp.findOne({
      email:req.body.email
  });
    if(otps.otp ==req.body.otp){
         return res.json({status_code:1,msg:"otp verified"})
    }else{
      return res.json({status_code:0,msg:"invalid otp"})
    }
  },

  gen_newpassword:async(req,res) =>{
    let validation = new Validator(req.body, {
      email: 'required|email',
      newpassword:'required',
      confirmpassword:'required',
    });
    if (validation.fails()) {
      let err_key = Object.keys(Object.entries(validation.errors)[0][1])[0];
      return res.json(res.json(validation.errors.first(err_key)));
    }
    const otps = await User.findOne({
      email:req.body.email
  });
 
  try{
    if(req.body.newpassword !=otps.password){
      console.log('ushdfksd')
      await otps.updateOne({password:req.body.newpassword});
        // console.log(up)
           return res.json({msg:"password changed successfully"})
    }
  }catch(err){
    console.log(err,'sdhfkls');
  }
  
},

  user_get: async (req, res) => {
        const user_id =  req.user.id;
        const user = await User.findOne({
          attributes: { exclude: ['password'] },
          where: {
          id: user_id  
      }});
        return  res.json(user)
    
  },
  all_user_get: async (req, res) => {
    const user_id =  req.user.id;
    const user = await User.find({
      attributes: { exclude: ['password'] },
         });
    return  res.json(user)

}


}