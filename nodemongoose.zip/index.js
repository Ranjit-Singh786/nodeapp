import express  from "express";
const app = express(); 
import conf from "./config/db.js";


import * as dotenv from 'dotenv';;
import Router from "./routers/authRoute.js";
dotenv.config()
app.use(express.json())


app.use(function(req, res, next) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Allow-Credentials', true);
    next();
});
app.use(Router)
const PORT=process.env.PORT;
conf();
  


// app.use(authRoute);
app.listen(PORT,(req,res)=>{
    console.log('welcome to this port',PORT);
});
