import jwt from "jsonwebtoken";
import User from "../models/user.js";
import Token from "../models/token.js";
import fs from "fs";

var Authorization = function (req, res, next) {
    var token = req.headers.authorization;
    token = token?.split(' ')[1] || null;
     console.log(token);
    if(!token){
        res.json({status_code:0,message:"Unable to Authorized User"})
    }
     var publickey = fs.readFileSync("./keys/Public.pem", "utf-8");
    jwt.verify(token, publickey, async function (err, decoded) {
        console.log(decoded);
         
        if (err) {
            return res.status(401).send("invalid response") ;
        };
        const is_token = await Token.findOne({
            raw: true,
            where: {
            token_id: decoded.token_ids   
        }});

        if(!is_token)
        {
            return res.status(401).send("invalid") ;
        }
        let user_id = is_token.user_id;
        const user = await User.findOne({
            raw: true,
            where: {
            id: decoded.user_id   
        }});

        req.user = user;
        next();
    });
}

export default Authorization;