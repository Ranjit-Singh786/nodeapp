import mongoose from "mongoose";

const OtpSchema = new mongoose.Schema({
   user_id:{
      type:String,
      required:true,

   },
   email:{
      type:String,
      required:true,

   },
   otp:{
    type: Number,
    required: true,
    unique: true,
    integer: true,
 },
 expired_at:{
    type: String,
    required:true,
 }    
},{force:true},
{timestamps:true}
);

const Otp = mongoose.model("otp",OtpSchema)
export default Otp;
