import mongoose from "mongoose";

const TokenSchema = new mongoose.Schema({
   user_id:{
      type:String,
      required:true,

   },
   token_id:{
      type:String,
      required:true,

   },    
},
{timestamps:true}
);

const Token = mongoose.model("token",TokenSchema)
export default Token;
