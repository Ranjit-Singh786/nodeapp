import express from "express";
import authController from "../controllers/authController.js";
import Authorization from "../middleware/authmiddle.js";
const Router = express.Router();

Router.post("/register",authController.Register);
Router.post("/login_user",authController.loginUser);
///////////////route of password changed///////////////
Router.post("/forgot_p",authController.forgot_password);
Router.post("/otp_verify",authController.otp_verify);
Router.put("/password_confirmation",authController.gen_newpassword);

////////////////////////customer routers /////////////////////
Router.get("/get_profile",Authorization,authController.user_get);
Router.get("/all_user",Authorization,authController.all_user_get);

export default Router;